export const SelectComponent = () => {
  return (
      <div>
          Select Type
          <select>
              <option>All</option>
          </select>
      </div>
  )
};
