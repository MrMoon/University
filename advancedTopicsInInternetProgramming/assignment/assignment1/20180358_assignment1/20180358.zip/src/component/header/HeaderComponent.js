export const HeaderComponent = () => {
    return (
      <div>
          <h1>Query PSUT students</h1>
          <p>At PSUT we have the best students</p>
      </div>
    );
}
