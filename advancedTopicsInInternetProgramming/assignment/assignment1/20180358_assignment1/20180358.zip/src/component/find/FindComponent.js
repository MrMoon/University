export const FindComponent = ({link}) => {
    return (
        <div>
            <a href={link}>
                <button>
                    Find out more
                </button>
            </a>
        </div>
    );
};
