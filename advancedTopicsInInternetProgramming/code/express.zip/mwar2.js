var express = require('express');
var app = express();

//Middleware function to log request protocol

app.use('/', function(req, res, next){
   console.log("test received at " + Date.now());
 next();
});
app.use('/things', function(req, res, next){
   console.log("A request for things received at " + Date.now());
 
});

// Route handler that sends the response
app.get('/things', function(req, res){
   res.send('Things');
});

app.listen(3000);